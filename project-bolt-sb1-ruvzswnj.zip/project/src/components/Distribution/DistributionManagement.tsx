import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Distribution } from '../../types';
import { Plus, Search, Truck as TruckIcon, CheckCircle, Clock } from 'lucide-react';

const DistributionManagement: React.FC = () => {
  const [distributions, setDistributions] = useState<Distribution[]>([]);
  const [products, setProducts] = useState([]);
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const [formData, setFormData] = useState({
    product_id: '',
    from_store_id: '',
    to_store_id: '',
    quantity: '',
  });

  useEffect(() => {
    Promise.all([fetchDistributions(), fetchProducts(), fetchStores()]);
  }, []);

  const fetchDistributions = async () => {
    try {
      const { data, error } = await supabase
        .from('distribution')
        .select(`
          *,
          product:products(*),
          from_store:stores!distribution_from_store_id_fkey(*),
          to_store:stores!distribution_to_store_id_fkey(*)
        `)
        .order('distribution_date', { ascending: false });

      if (error) throw error;
      setDistributions(data || []);
    } catch (error) {
      console.error('Error fetching distributions:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const fetchStores = async () => {
    try {
      const { data, error } = await supabase
        .from('stores')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setStores(data || []);
    } catch (error) {
      console.error('Error fetching stores:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const quantity = parseInt(formData.quantity);

      // Check if source store has enough stock
      const { data: sourceStock } = await supabase
        .from('stock')
        .select('quantity')
        .eq('product_id', formData.product_id)
        .eq('store_id', formData.from_store_id)
        .single();

      if (!sourceStock || sourceStock.quantity < quantity) {
        alert('Insufficient stock at source location');
        setLoading(false);
        return;
      }

      // Create distribution record
      const distributionData = {
        product_id: formData.product_id,
        from_store_id: formData.from_store_id,
        to_store_id: formData.to_store_id,
        quantity,
        distribution_date: new Date().toISOString(),
        status: 'pending',
      };

      const { error: distributionError } = await supabase
        .from('distribution')
        .insert([distributionData]);

      if (distributionError) throw distributionError;

      // Update source store stock
      const { error: sourceError } = await supabase
        .from('stock')
        .update({ quantity: sourceStock.quantity - quantity })
        .eq('product_id', formData.product_id)
        .eq('store_id', formData.from_store_id);

      if (sourceError) throw sourceError;

      // Update destination store stock
      const { data: destStock } = await supabase
        .from('stock')
        .select('quantity')
        .eq('product_id', formData.product_id)
        .eq('store_id', formData.to_store_id)
        .single();

      if (destStock) {
        // Update existing stock
        const { error: destError } = await supabase
          .from('stock')
          .update({ quantity: destStock.quantity + quantity })
          .eq('product_id', formData.product_id)
          .eq('store_id', formData.to_store_id);

        if (destError) throw destError;
      } else {
        // Create new stock record
        const { error: destError } = await supabase
          .from('stock')
          .insert([{
            product_id: formData.product_id,
            store_id: formData.to_store_id,
            quantity,
          }]);

        if (destError) throw destError;
      }

      await fetchDistributions();
      setShowModal(false);
      setFormData({
        product_id: '',
        from_store_id: '',
        to_store_id: '',
        quantity: '',
      });
    } catch (error) {
      console.error('Error creating distribution:', error);
      alert('Error creating distribution');
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteDistribution = async (distributionId: string) => {
    try {
      const { error } = await supabase
        .from('distribution')
        .update({ status: 'completed' })
        .eq('id', distributionId);

      if (error) throw error;
      await fetchDistributions();
    } catch (error) {
      console.error('Error completing distribution:', error);
      alert('Error completing distribution');
    }
  };

  const filteredDistributions = distributions.filter(dist =>
    dist.product?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dist.from_store?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dist.to_store?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading && distributions.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Distribution Management</h1>
          <p className="text-gray-600">Manage product distribution between locations</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>New Distribution</span>
        </button>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search distributions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent w-full"
          />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Product & Quantity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  From → To
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredDistributions.map((distribution) => (
                <tr key={distribution.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="p-2 bg-blue-100 rounded-lg mr-3">
                        <TruckIcon className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {distribution.product?.name}
                        </div>
                        <div className="text-sm text-gray-500">
                          {distribution.quantity} units
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      <div className="flex items-center space-x-2">
                        <span>{distribution.from_store?.name}</span>
                        <span className="text-gray-400">→</span>
                        <span>{distribution.to_store?.name}</span>
                      </div>
                      <div className="text-xs text-gray-500">
                        {distribution.from_store?.area} → {distribution.to_store?.area}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {distribution.status === 'completed' ? (
                        <>
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Completed
                          </span>
                        </>
                      ) : (
                        <>
                          <Clock className="h-4 w-4 text-yellow-500 mr-2" />
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                            Pending
                          </span>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(distribution.distribution_date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {distribution.status === 'pending' && (
                      <button
                        onClick={() => handleCompleteDistribution(distribution.id)}
                        className="text-green-600 hover:text-green-900 text-sm bg-green-100 hover:bg-green-200 px-3 py-1 rounded-lg transition-colors"
                      >
                        Complete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredDistributions.length === 0 && !loading && (
        <div className="text-center py-12">
          <TruckIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No distributions found</h3>
          <p className="text-gray-500 mb-4">
            {searchTerm ? 'No distributions match your search criteria.' : 'Get started by creating your first distribution.'}
          </p>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">New Distribution</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Product</label>
                <select
                  value={formData.product_id}
                  onChange={(e) => setFormData({ ...formData, product_id: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Select Product</option>
                  {products.map((product: any) => (
                    <option key={product.id} value={product.id}>
                      {product.name} ({product.sku})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">From Store</label>
                <select
                  value={formData.from_store_id}
                  onChange={(e) => setFormData({ ...formData, from_store_id: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Select Source Store</option>
                  {stores.map((store: any) => (
                    <option key={store.id} value={store.id}>
                      {store.name} ({store.area})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">To Store</label>
                <select
                  value={formData.to_store_id}
                  onChange={(e) => setFormData({ ...formData, to_store_id: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Select Destination Store</option>
                  {stores
                    .filter((store: any) => store.id !== formData.from_store_id)
                    .map((store: any) => (
                      <option key={store.id} value={store.id}>
                        {store.name} ({store.area})
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
                <input
                  type="number"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  required
                  min="1"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setFormData({
                      product_id: '',
                      from_store_id: '',
                      to_store_id: '',
                      quantity: '',
                    });
                  }}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Processing...' : 'Create Distribution'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default DistributionManagement;