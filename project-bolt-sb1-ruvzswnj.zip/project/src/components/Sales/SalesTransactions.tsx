import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { SalesTransaction } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { Plus, Search, ShoppingCart, Calendar } from 'lucide-react';

const SalesTransactions: React.FC = () => {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<SalesTransaction[]>([]);
  const [products, setProducts] = useState([]);
  const [stores, setStores] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const [formData, setFormData] = useState({
    product_id: '',
    salesman_id: user?.id || '',
    store_id: '',
    quantity: '',
    price: '',
  });

  useEffect(() => {
    Promise.all([fetchTransactions(), fetchProducts(), fetchStores(), fetchUsers()]);
  }, []);

  const fetchTransactions = async () => {
    try {
      let query = supabase
        .from('sales_transactions')
        .select(`
          *,
          product:products(*),
          salesman:users!sales_transactions_salesman_id_fkey(*),
          store:stores(*)
        `)
        .order('transaction_date', { ascending: false });

      // If user is not admin, only show their own transactions
      if (user?.role !== 'admin') {
        if (user?.role === 'sales') {
          query = query.eq('salesman_id', user.id);
        } else if (user?.role === 'outlet') {
          // Get transactions for stores in the same area
          query = query.eq('store.area', user.area);
        }
      }

      const { data, error } = await query;
      if (error) throw error;
      setTransactions(data || []);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const fetchStores = async () => {
    try {
      let query = supabase.from('stores').select('*').order('name');
      
      // If user is outlet, only show stores in their area
      if (user?.role === 'outlet') {
        query = query.eq('area', user.area);
      }

      const { data, error } = await query;
      if (error) throw error;
      setStores(data || []);
    } catch (error) {
      console.error('Error fetching stores:', error);
    }
  };

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .in('role', ['sales'])
        .order('name');
      
      if (error) throw error;
      setUsers(data || []);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const selectedProduct = products.find((p: any) => p.id === formData.product_id);
      const quantity = parseInt(formData.quantity);
      const unitPrice = formData.price ? parseFloat(formData.price) : selectedProduct?.price || 0;
      
      const transactionData = {
        product_id: formData.product_id,
        salesman_id: formData.salesman_id || user?.id,
        store_id: formData.store_id,
        quantity,
        total_price: quantity * unitPrice,
        transaction_date: new Date().toISOString(),
      };

      // Insert transaction
      const { error: transactionError } = await supabase
        .from('sales_transactions')
        .insert([transactionData]);

      if (transactionError) throw transactionError;

      // Update stock
      const { data: currentStock } = await supabase
        .from('stock')
        .select('quantity')
        .eq('product_id', formData.product_id)
        .eq('store_id', formData.store_id)
        .single();

      if (currentStock) {
        const { error: stockError } = await supabase
          .from('stock')
          .update({ quantity: Math.max(0, currentStock.quantity - quantity) })
          .eq('product_id', formData.product_id)
          .eq('store_id', formData.store_id);

        if (stockError) throw stockError;
      }

      await fetchTransactions();
      setShowModal(false);
      setFormData({
        product_id: '',
        salesman_id: user?.id || '',
        store_id: '',
        quantity: '',
        price: '',
      });
    } catch (error) {
      console.error('Error saving transaction:', error);
      alert('Error saving transaction');
    } finally {
      setLoading(false);
    }
  };

  const handleProductChange = (productId: string) => {
    const product = products.find((p: any) => p.id === productId);
    setFormData({
      ...formData,
      product_id: productId,
      price: product?.price.toString() || '',
    });
  };

  const filteredTransactions = transactions.filter(transaction =>
    transaction.product?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    transaction.salesman?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    transaction.store?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const calculateTotal = () => {
    const quantity = parseInt(formData.quantity) || 0;
    const price = parseFloat(formData.price) || 0;
    return quantity * price;
  };

  if (loading && transactions.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Sales Transactions</h1>
          <p className="text-gray-600">Manage and track all sales transactions</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>New Transaction</span>
        </button>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Search transactions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent w-full"
          />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Transaction
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Salesman
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Store
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredTransactions.map((transaction) => (
                <tr key={transaction.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="p-2 bg-purple-100 rounded-lg mr-3">
                        <ShoppingCart className="h-4 w-4 text-purple-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {transaction.product?.name}
                        </div>
                        <div className="text-sm text-gray-500">
                          {transaction.quantity} units × Rp {(transaction.total_price / transaction.quantity).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{transaction.salesman?.name}</div>
                    <div className="text-sm text-gray-500">{transaction.salesman?.email}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{transaction.store?.name}</div>
                    <div className="text-sm text-gray-500">{transaction.store?.area}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-green-600">
                      Rp {transaction.total_price.toLocaleString()}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-900">
                      <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                      {new Date(transaction.transaction_date).toLocaleDateString()}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredTransactions.length === 0 && !loading && (
        <div className="text-center py-12">
          <ShoppingCart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No transactions found</h3>
          <p className="text-gray-500 mb-4">
            {searchTerm ? 'No transactions match your search criteria.' : 'Get started by recording your first sale.'}
          </p>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">New Sales Transaction</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Product</label>
                <select
                  value={formData.product_id}
                  onChange={(e) => handleProductChange(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Select Product</option>
                  {products.map((product: any) => (
                    <option key={product.id} value={product.id}>
                      {product.name} - Rp {product.price.toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>

              {(user?.role === 'admin') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Salesman</label>
                  <select
                    value={formData.salesman_id}
                    onChange={(e) => setFormData({ ...formData, salesman_id: e.target.value })}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="">Select Salesman</option>
                    {users.map((salesUser: any) => (
                      <option key={salesUser.id} value={salesUser.id}>
                        {salesUser.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Store</label>
                <select
                  value={formData.store_id}
                  onChange={(e) => setFormData({ ...formData, store_id: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Select Store</option>
                  {stores.map((store: any) => (
                    <option key={store.id} value={store.id}>
                      {store.name} ({store.area})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
                <input
                  type="number"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  required
                  min="1"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Unit Price (Rp)</label>
                <input
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  required
                  min="0"
                  step="0.01"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>

              {formData.quantity && formData.price && (
                <div className="bg-purple-50 p-3 rounded-lg">
                  <p className="text-sm font-medium text-purple-800">
                    Total: Rp {calculateTotal().toLocaleString()}
                  </p>
                </div>
              )}

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setFormData({
                      product_id: '',
                      salesman_id: user?.id || '',
                      store_id: '',
                      quantity: '',
                      price: '',
                    });
                  }}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Processing...' : 'Create Transaction'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default SalesTransactions;